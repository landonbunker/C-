using System.Diagnostics.Eventing.Reader;
using System.Net.Security;

namespace BunkerLA2
{
    public partial class Form2 : Form
    {
        // initialize all the needed variables
        TextBox[,] textBoxes = new TextBox[6, 5];
        private TableLayoutPanel tableLayoutPanel1;
        private TextBox textBox1;
        private TextBox textBox2;
        private TextBox textBox3;
        private TextBox textBox4;
        private TextBox textBox5;
        private TextBox textBox6;
        private TextBox textBox7;
        private TextBox textBox8;
        private TextBox textBox9;
        private TextBox textBox10;
        private TextBox textBox11;
        private TextBox textBox12;
        private TextBox textBox13;
        private TextBox textBox14;
        private TextBox textBox15;
        private TextBox textBox16;
        private TextBox textBox17;
        private TextBox textBox18;
        private TextBox textBox19;
        private TextBox textBox20;
        private TextBox textBox21;
        private TextBox textBox22;
        private TextBox textBox23;
        private TextBox textBox24;
        private TextBox textBox25;
        private TextBox textBox26;
        private TextBox textBox27;
        private TextBox textBox28;
        private TextBox textBox29;
        private TextBox textBox30;
        String[] guesses = new string[5];
        bool gameOver = false;
        bool gameOverguesses = false;
        Game_Logic game_logic = new Game_Logic();

        public Form2()
        {
            InitializeComponent();
        }



        public void OnTextBoxChange(object sender, EventArgs e)
        {

        }

        public void OnClickhandler(object sender, EventArgs e)
        {

        }

        public void OnGameEndHandler(object sender, EventArgs e)
        {

        }

        public void OnGuessResponseHandler(object sender, EventArgs e)
        {

        }

        //checking to see if all the columns in a given row have text and returns true if so
        public bool AllColumnsFilled(int row)
        {
            bool returnValue = true;

            for (int i = 0; i < 6; i++)
            {
                TextBox textBox = (TextBox)tableLayoutPanel1.GetControlFromPosition(i, row);

                if (textBox.Text.Length == 0)
                {
                    returnValue = false;
                    break;
                }

                i++;

            }
            return returnValue;
        }

        //initializing all the textboxes in the table
        private void InitializeComponent()
        {
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.textBox13 = new System.Windows.Forms.TextBox();
            this.textBox14 = new System.Windows.Forms.TextBox();
            this.textBox15 = new System.Windows.Forms.TextBox();
            this.textBox16 = new System.Windows.Forms.TextBox();
            this.textBox17 = new System.Windows.Forms.TextBox();
            this.textBox18 = new System.Windows.Forms.TextBox();
            this.textBox19 = new System.Windows.Forms.TextBox();
            this.textBox20 = new System.Windows.Forms.TextBox();
            this.textBox21 = new System.Windows.Forms.TextBox();
            this.textBox22 = new System.Windows.Forms.TextBox();
            this.textBox23 = new System.Windows.Forms.TextBox();
            this.textBox24 = new System.Windows.Forms.TextBox();
            this.textBox25 = new System.Windows.Forms.TextBox();
            this.textBox26 = new System.Windows.Forms.TextBox();
            this.textBox27 = new System.Windows.Forms.TextBox();
            this.textBox28 = new System.Windows.Forms.TextBox();
            this.textBox29 = new System.Windows.Forms.TextBox();
            this.textBox30 = new System.Windows.Forms.TextBox();
            this.tableLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 5;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 20F));
            this.tableLayoutPanel1.Controls.Add(this.textBox1, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.textBox2, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.textBox3, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.textBox4, 3, 0);
            this.tableLayoutPanel1.Controls.Add(this.textBox5, 4, 0);
            this.tableLayoutPanel1.Controls.Add(this.textBox6, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.textBox7, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.textBox8, 2, 1);
            this.tableLayoutPanel1.Controls.Add(this.textBox9, 3, 1);
            this.tableLayoutPanel1.Controls.Add(this.textBox10, 4, 1);
            this.tableLayoutPanel1.Controls.Add(this.textBox11, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.textBox12, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.textBox13, 2, 2);
            this.tableLayoutPanel1.Controls.Add(this.textBox14, 3, 2);
            this.tableLayoutPanel1.Controls.Add(this.textBox15, 4, 2);
            this.tableLayoutPanel1.Controls.Add(this.textBox16, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.textBox17, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.textBox18, 2, 3);
            this.tableLayoutPanel1.Controls.Add(this.textBox19, 3, 3);
            this.tableLayoutPanel1.Controls.Add(this.textBox20, 4, 3);
            this.tableLayoutPanel1.Controls.Add(this.textBox21, 0, 4);
            this.tableLayoutPanel1.Controls.Add(this.textBox22, 1, 4);
            this.tableLayoutPanel1.Controls.Add(this.textBox23, 2, 4);
            this.tableLayoutPanel1.Controls.Add(this.textBox24, 3, 4);
            this.tableLayoutPanel1.Controls.Add(this.textBox25, 4, 4);
            this.tableLayoutPanel1.Controls.Add(this.textBox26, 0, 5);
            this.tableLayoutPanel1.Controls.Add(this.textBox27, 1, 5);
            this.tableLayoutPanel1.Controls.Add(this.textBox28, 2, 5);
            this.tableLayoutPanel1.Controls.Add(this.textBox29, 3, 5);
            this.tableLayoutPanel1.Controls.Add(this.textBox30, 4, 5);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(12, 12);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 6;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 16.66667F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(270, 244);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // textBox1
            // 
            this.textBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBox1.Font = new System.Drawing.Font("Consolas", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.textBox1.Location = new System.Drawing.Point(3, 3);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(48, 39);
            this.textBox1.TabIndex = 0;
            this.textBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // textBox2
            // 
            this.textBox2.Font = new System.Drawing.Font("Consolas", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.textBox2.Location = new System.Drawing.Point(57, 3);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(48, 39);
            this.textBox2.TabIndex = 1;
            this.textBox2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox3
            // 
            this.textBox3.Font = new System.Drawing.Font("Consolas", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.textBox3.Location = new System.Drawing.Point(111, 3);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(48, 39);
            this.textBox3.TabIndex = 2;
            this.textBox3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox4
            // 
            this.textBox4.Font = new System.Drawing.Font("Consolas", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.textBox4.Location = new System.Drawing.Point(165, 3);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(48, 39);
            this.textBox4.TabIndex = 3;
            this.textBox4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox5
            // 
            this.textBox5.Font = new System.Drawing.Font("Consolas", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.textBox5.Location = new System.Drawing.Point(219, 3);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(48, 39);
            this.textBox5.TabIndex = 4;
            this.textBox5.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox6
            // 
            this.textBox6.Font = new System.Drawing.Font("Consolas", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.textBox6.Location = new System.Drawing.Point(3, 43);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(48, 39);
            this.textBox6.TabIndex = 5;
            this.textBox6.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox7
            // 
            this.textBox7.Font = new System.Drawing.Font("Consolas", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.textBox7.Location = new System.Drawing.Point(57, 43);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(48, 39);
            this.textBox7.TabIndex = 6;
            this.textBox7.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox8
            // 
            this.textBox8.Font = new System.Drawing.Font("Consolas", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.textBox8.Location = new System.Drawing.Point(111, 43);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(48, 39);
            this.textBox8.TabIndex = 7;
            this.textBox8.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox9
            // 
            this.textBox9.Font = new System.Drawing.Font("Consolas", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.textBox9.Location = new System.Drawing.Point(165, 43);
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(48, 39);
            this.textBox9.TabIndex = 8;
            this.textBox9.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox10
            // 
            this.textBox10.Font = new System.Drawing.Font("Consolas", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.textBox10.Location = new System.Drawing.Point(219, 43);
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(48, 39);
            this.textBox10.TabIndex = 9;
            this.textBox10.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox11
            // 
            this.textBox11.Font = new System.Drawing.Font("Consolas", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.textBox11.Location = new System.Drawing.Point(3, 83);
            this.textBox11.Name = "textBox11";
            this.textBox11.Size = new System.Drawing.Size(48, 39);
            this.textBox11.TabIndex = 10;
            this.textBox11.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox12
            // 
            this.textBox12.Font = new System.Drawing.Font("Consolas", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.textBox12.Location = new System.Drawing.Point(57, 83);
            this.textBox12.Name = "textBox12";
            this.textBox12.Size = new System.Drawing.Size(48, 39);
            this.textBox12.TabIndex = 11;
            this.textBox12.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox13
            // 
            this.textBox13.Font = new System.Drawing.Font("Consolas", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.textBox13.Location = new System.Drawing.Point(111, 83);
            this.textBox13.Name = "textBox13";
            this.textBox13.Size = new System.Drawing.Size(48, 39);
            this.textBox13.TabIndex = 12;
            this.textBox13.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox14
            // 
            this.textBox14.Font = new System.Drawing.Font("Consolas", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.textBox14.Location = new System.Drawing.Point(165, 83);
            this.textBox14.Name = "textBox14";
            this.textBox14.Size = new System.Drawing.Size(48, 39);
            this.textBox14.TabIndex = 13;
            this.textBox14.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox15
            // 
            this.textBox15.Font = new System.Drawing.Font("Consolas", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.textBox15.Location = new System.Drawing.Point(219, 83);
            this.textBox15.Name = "textBox15";
            this.textBox15.Size = new System.Drawing.Size(48, 39);
            this.textBox15.TabIndex = 14;
            this.textBox15.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox16
            // 
            this.textBox16.Font = new System.Drawing.Font("Consolas", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.textBox16.Location = new System.Drawing.Point(3, 123);
            this.textBox16.Name = "textBox16";
            this.textBox16.Size = new System.Drawing.Size(48, 39);
            this.textBox16.TabIndex = 15;
            this.textBox16.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox17
            // 
            this.textBox17.Font = new System.Drawing.Font("Consolas", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.textBox17.Location = new System.Drawing.Point(57, 123);
            this.textBox17.Name = "textBox17";
            this.textBox17.Size = new System.Drawing.Size(48, 39);
            this.textBox17.TabIndex = 16;
            this.textBox17.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox18
            // 
            this.textBox18.Font = new System.Drawing.Font("Consolas", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.textBox18.Location = new System.Drawing.Point(111, 123);
            this.textBox18.Name = "textBox18";
            this.textBox18.Size = new System.Drawing.Size(48, 39);
            this.textBox18.TabIndex = 17;
            this.textBox18.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox19
            // 
            this.textBox19.Font = new System.Drawing.Font("Consolas", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.textBox19.Location = new System.Drawing.Point(165, 123);
            this.textBox19.Name = "textBox19";
            this.textBox19.Size = new System.Drawing.Size(48, 39);
            this.textBox19.TabIndex = 18;
            this.textBox19.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox20
            // 
            this.textBox20.Font = new System.Drawing.Font("Consolas", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.textBox20.Location = new System.Drawing.Point(219, 123);
            this.textBox20.Name = "textBox20";
            this.textBox20.Size = new System.Drawing.Size(48, 39);
            this.textBox20.TabIndex = 19;
            this.textBox20.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox21
            // 
            this.textBox21.Font = new System.Drawing.Font("Consolas", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.textBox21.Location = new System.Drawing.Point(3, 163);
            this.textBox21.Name = "textBox21";
            this.textBox21.Size = new System.Drawing.Size(48, 39);
            this.textBox21.TabIndex = 20;
            this.textBox21.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox22
            // 
            this.textBox22.Font = new System.Drawing.Font("Consolas", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.textBox22.Location = new System.Drawing.Point(57, 163);
            this.textBox22.Name = "textBox22";
            this.textBox22.Size = new System.Drawing.Size(48, 39);
            this.textBox22.TabIndex = 21;
            this.textBox22.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox23
            // 
            this.textBox23.Font = new System.Drawing.Font("Consolas", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.textBox23.Location = new System.Drawing.Point(111, 163);
            this.textBox23.Name = "textBox23";
            this.textBox23.Size = new System.Drawing.Size(48, 39);
            this.textBox23.TabIndex = 22;
            this.textBox23.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox24
            // 
            this.textBox24.Font = new System.Drawing.Font("Consolas", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.textBox24.Location = new System.Drawing.Point(165, 163);
            this.textBox24.Name = "textBox24";
            this.textBox24.Size = new System.Drawing.Size(48, 39);
            this.textBox24.TabIndex = 23;
            this.textBox24.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox25
            // 
            this.textBox25.Font = new System.Drawing.Font("Consolas", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.textBox25.Location = new System.Drawing.Point(219, 163);
            this.textBox25.Name = "textBox25";
            this.textBox25.Size = new System.Drawing.Size(48, 39);
            this.textBox25.TabIndex = 24;
            this.textBox25.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox26
            // 
            this.textBox26.Font = new System.Drawing.Font("Consolas", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.textBox26.Location = new System.Drawing.Point(3, 203);
            this.textBox26.Name = "textBox26";
            this.textBox26.Size = new System.Drawing.Size(48, 39);
            this.textBox26.TabIndex = 25;
            this.textBox26.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox27
            // 
            this.textBox27.Font = new System.Drawing.Font("Consolas", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.textBox27.Location = new System.Drawing.Point(57, 203);
            this.textBox27.Name = "textBox27";
            this.textBox27.Size = new System.Drawing.Size(48, 39);
            this.textBox27.TabIndex = 26;
            this.textBox27.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox28
            // 
            this.textBox28.Font = new System.Drawing.Font("Consolas", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.textBox28.Location = new System.Drawing.Point(111, 203);
            this.textBox28.Name = "textBox28";
            this.textBox28.Size = new System.Drawing.Size(48, 39);
            this.textBox28.TabIndex = 27;
            this.textBox28.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox29
            // 
            this.textBox29.Font = new System.Drawing.Font("Consolas", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.textBox29.Location = new System.Drawing.Point(165, 203);
            this.textBox29.Name = "textBox29";
            this.textBox29.Size = new System.Drawing.Size(48, 39);
            this.textBox29.TabIndex = 28;
            this.textBox29.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox30
            // 
            this.textBox30.Font = new System.Drawing.Font("Consolas", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.textBox30.Location = new System.Drawing.Point(219, 203);
            this.textBox30.Name = "textBox30";
            this.textBox30.Size = new System.Drawing.Size(48, 39);
            this.textBox30.TabIndex = 29;
            this.textBox30.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Form2
            // 
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(284, 261);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Name = "Form2";
            this.Text = "Worlde Copy";
            this.Load += new System.EventHandler(this.Form2_Load);
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            this.ResumeLayout(false);

        }

        //adding the events to the textboxes in the table layout
        private void Form2_Load(object sender, EventArgs e)
        {
            foreach (var box in tableLayoutPanel1.Controls)
            {
                if (box is TextBox)
                {
                    (box as TextBox).TextChanged += Form2_TextChanged;
                    (box as TextBox).KeyDown += Form2_KeyDown;
                }
            }


            this.KeyDown += Form2_KeyDown;


        }

        private void Form2_KeyDown(object? sender, KeyEventArgs e)
        {
            bool guessIsWord;

            //checking to see if the sender has text
            if (sender is TextBox && sender != null)
            {
                TextBox tbox = (sender as TextBox);

                //if the user presses enter which is the guess button
                if (e.KeyValue == 13)
                {

                    //if the user has filled all the columns in the row
                    if (AllColumnsFilled(game_logic.GetGuess()))
                    {

                        //checking to see if the guess is a word in the word bank
                        string currentGuess = getGuess(game_logic.GetGuess());

                        guessIsWord = game_logic.IsGuessAWord(currentGuess);

                        //if a word then update the letter states and check if the word is the answer
                        if (guessIsWord)
                        {

                            List<Game_Logic.letterState> letterStates = new List<Game_Logic.letterState>();
                            for (int i = 0; i < 5; i++)
                            {
                                Game_Logic.letterState ls = game_logic.correctLetterInWord(currentGuess[i], i);
                                letterStates.Add(ls);
                                changeTextColor(ls, i, game_logic.GetGuess());
                            }

                            SetAllRowsReadOnly(game_logic.GetGuess());
                            gameOver = GameOver(letterStates, game_logic.GetGuess());
                            gameOverguesses = GameOverGuesses(game_logic.GetGuess());
                            game_logic.IncrementGuess();


                        }

                        //if not a word then dont make the textboxes read only and inform the user
                        else
                        {
                            System.Windows.Forms.MessageBox.Show("That is not a word in our list");
                        }

                        //checking to see if the game is over and they win
                        if (gameOver)
                        {
                            System.Windows.Forms.MessageBox.Show("You Win!");
                            this.Close();
                        }

                        //checking to see if the game is over and the user loses
                        else if (gameOverguesses && !gameOver)
                        {
                            System.Windows.Forms.MessageBox.Show("You Lose!  \nThe word was " + game_logic.getWord());
                            this.Close();
                        }

                    }

                }

                //if the user presses backspace it will go to previous tab
                else if (e.KeyValue == 8)
                {
                    if (!IsFirstColumn(tbox, game_logic.GetGuess()))
                    {
                        SendKeys.Send("+{TAB}");
                    }
                }
            }

        }

        //helper method for the tab index so that it will not go back if it is the first col
        private bool IsFirstColumn(TextBox textBox, int row)
        {
            return ((TextBox)tableLayoutPanel1.GetControlFromPosition(0, row) == textBox);
        }

        //checking to see if they have guesses all their guesses
        private bool GameOverGuesses(int guesses)
        {
            bool returnValue = false;
            if (guesses == 5)
            {
                returnValue = true;
            }

            return returnValue;
        }

        //checking to see if they have guessed the right word and if they have return true
        private bool GameOver(List<Game_Logic.letterState> ls, int guesses)
        {
            bool returnValue = false;

            for (int i = 0; i < 5; i++)
            {
                if (ls[i] == Game_Logic.letterState.CorrectInCorrectPlace)
                {
                    returnValue = true;
                }
                else
                {
                    returnValue = false;
                    break;
                }
            }

            return returnValue;

        }

        //changing the text color based on the letter state at the given col and row in the table
        private void changeTextColor(Game_Logic.letterState ls, int col, int row)
        {

            TextBox tbox = (TextBox)tableLayoutPanel1.GetControlFromPosition(col, row);

            if (ls == Game_Logic.letterState.notCorrect)
            {
                tbox.BackColor = Color.LightGray;

            }
            else if (ls == Game_Logic.letterState.correctNotInPlace)
            {
                tbox.BackColor = Color.Yellow;
            }
            else if (ls == Game_Logic.letterState.CorrectInCorrectPlace)
            {
                tbox.BackColor = Color.LimeGreen;
            }


        }

        //return the guess in a string form from the row that the user has guessed in
        private string getGuess(int row)
        {
            string guess = string.Empty;
            for (int i = 0; i < 5; i++)
            {
                TextBox textbox = (TextBox)tableLayoutPanel1.GetControlFromPosition(i, row);
                guess += textbox.Text;
            }

            return guess;
        }
        //set all the textboxes in the row to read only so the user can not change their guess
        private void SetAllRowsReadOnly(int row)
        {
            for (int i = 0; i < 5; i++)
            {
                TextBox textbox = (TextBox)tableLayoutPanel1.GetControlFromPosition(i, row);
                textbox.Enabled = false;
            }
        }

        //event that makes sure that the user can not put more then one letter per text box and automatically moves the cursor to the next box
        private void Form2_TextChanged(object? sender, EventArgs e)
        {
            if (sender != null && sender is TextBox)
            {
                TextBox textBox = (sender as TextBox);

                if (textBox.TextLength > 1)
                {
                    textBox.Text = textBox.Text.Substring(0, textBox.TextLength - 1);

                }

                if (textBox.TextLength == 1)
                {
                    SendKeys.Send("{Tab}");

                }


            }
        }

        private void TextBox1_TextChanged(object? sender, EventArgs e)
        {
            throw new NotImplementedException();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }

}