﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BunkerLA2
{
    public class EventArgsClass : EventArgs
    {
        public enum letterState
        {
            notCorrect,
            correctInWrongSpot,
            correctInCorrectSpot,
        }

        public void GuessCheckEventArgs(object sender, string word)
        {
            

        }

        public void GuessResponseEventArgs(object sender, letterState state)
        {
            letterState currentState = state;

           

           
        }

        public void EndGameEventArgs(object sender, string word)
        {

        }
    }
}
