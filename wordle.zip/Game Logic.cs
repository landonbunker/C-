﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BunkerLA2
{
    //game logic class
    public class Game_Logic
    {
        //private enum to keep track of all the letter states
        public enum letterState
        {
            notCorrect,
            correctNotInPlace,
            CorrectInCorrectPlace,
        }

        //private instance variables which include the word bank and the solution word
        Random random = new Random();

        //read from text file from a text location
        string[] words = System.IO.File.ReadAllLines(@"C:\Users\lando\OneDrive\Desktop\wordle words.txt");
        int guess = 0;
        private string solutionWord;

        //constructor
        public Game_Logic()
        {
            solutionWord = this.PickRandomWord();
        }

        //getter to get the solution word
        public string getWord()
        {
            return solutionWord;
        }

        //checking to see if the word is in the word bank
        public bool IsGuessAWord(string word)
        {
            return words.Contains(word);
        }

        //checking to see if the letter is in the word and in the correct spot and then returning the letter state
        public letterState correctLetterInWord(char letter, int index)
        {
            letterState returnValue = letterState.notCorrect;

            if (String.Equals(letter, solutionWord[index]))
            {
                returnValue = letterState.CorrectInCorrectPlace;
            }

            else if (solutionWord.Contains(letter))
            {
                returnValue = letterState.correctNotInPlace;
            }

            else
            {
                returnValue = letterState.notCorrect;
            }

            return returnValue;
        }

        //increment the guess counter so the gui can understand which row it is on
        public void IncrementGuess()
        {
            this.guess++;
        }

        //get the working row and guess counter
        public int GetGuess()
        {
            return this.guess;
        }
        //pick a random word from the work bank and return it
        public string PickRandomWord()
        {
            int index = random.Next(words.Length);
            Console.WriteLine(words[index]);

            return words[index];
        }
    }
}
