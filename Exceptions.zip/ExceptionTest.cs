﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exceptions
{
    public class ExceptionTest
    {
        public void Test()
        {
            throw new HeDiesExeption("Apollo, NOOOOOO!");
        }
    }
}
