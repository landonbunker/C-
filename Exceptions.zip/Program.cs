﻿using Exceptions;
using System.Xml;

ExceptionTest et = new ExceptionTest();
try
{
    et.Test();
}
catch(HeDiesExeption ex)
{
    Console.WriteLine(ex.StackTrace);
    Console.WriteLine(ex.Message);
    Console.WriteLine(ex.HelpLink);
    Console.WriteLine(ex.TargetSite);
}
finally
{
    Console.WriteLine("Cue the training montage!");
}



