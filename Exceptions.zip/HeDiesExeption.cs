﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exceptions
{
    public class HeDiesExeption : Exception
    {

        
        public HeDiesExeption()
        {

        }

        public HeDiesExeption(string exMessage) : base(exMessage)
        {

        }

        public HeDiesExeption(string exMessage, Exception ex) : base(exMessage, ex)
        {

        }
    }
}
