﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace sweeper
{
    public partial class Cell : UserControl
    {
        //private instance variables
        public event EventHandler<CellClickEventArgs> CellClick;
        Panel background = new Panel();
        Label textControl = new Label();
        Button button = new Button();
        Size cellSize = new System.Drawing.Size(24, 24);
        bool isBomb = false;
        int number = 0;
        int x;
        int y;

        //different bitmaps for artwork
        Bitmap flagBMP = new Bitmap(System.Reflection.Assembly.GetEntryAssembly().GetManifestResourceStream("sweeper.Bitmap1.bmp"));
        Bitmap bombBMP = new Bitmap(System.Reflection.Assembly.GetEntryAssembly().GetManifestResourceStream("sweeper.Bitmap2.bmp"));




        public Cell()
        {
            InitializeComponent();

            //setting all the variables when the cell is intialized
            this.Size = cellSize;
            background.Size = this.Size;
            textControl.Size = this.Size;
            background.BackColor = Color.Aqua;
            button.Size = this.Size;
            button.Click += ButtonClick_EventHandler;
            button.MouseDown += ButtonClick1_EventHandler;
            this.Controls.Add(button);
            this.Controls.Add(textControl);
            this.Controls.Add(background);
            
         


        }

        //right click button handler to place the flag and diffuse the bomb
        private void ButtonClick1_EventHandler(object? sender, MouseEventArgs e)
        {
            if(e.Button == MouseButtons.Right)
            {
                button.Image = flagBMP;
                Image = flagBMP;
                this.isBomb = false;
            }
        }
            
        //button click the reveals the tile that you clicked on.
        public void ButtonClick_EventHandler(object ?sender, EventArgs e)
        {
            
            button.Visible = false;
            CellClickEventArgs args = new CellClickEventArgs(X, Y);
            OnCellClick(this, args);
            
        }
       

        protected virtual void OnCellClick(object sender, CellClickEventArgs e)
        {
            CellClick?.Invoke(sender, e);
        }

        public void PerformClick()
        {
            button.PerformClick();
        }

        //getters and setters
        public Size CellSize { get => cellSize; }
        public int X { get => x; set => x = value; }
        public int Y { get => y; set => y = value; }

        public String text { get => textControl.Text; set => textControl.Text = value; }
        public Color BackgroundColor { get => textControl.BackColor; set => textControl.BackColor = value; }
        public bool IsBomb { get => isBomb; set => isBomb = value; }
        public int Number { get => number; set => number = value; }

        public Image Image { get => textControl.Image; set => textControl.Image = value; }
        private void Cell_Load(object sender, EventArgs e)
        {

        }
    }
}
