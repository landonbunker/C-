using Microsoft.VisualBasic;
using System;
using System.Reflection.Metadata;
using System.Security.Cryptography.X509Certificates;

namespace sweeper
{
    public partial class Form1 : Form
    {
        //varaibles and bitmaps for the form
        private const string Path = "C:\\Users\\lando\\OneDrive\\Desktop\\New folder\\LifetimeStats.txt";
        int elapsedTime = 0;
        Cell[,] board = new Cell[10, 10];
        Random random = new Random();
        int MAXBOMBS = 12;
        int OVERALLLoSSES = 0;
        int OVERALLWINS = 0;
        bool endgame = false;
        Bitmap flagBMP = new Bitmap(System.Reflection.Assembly.GetEntryAssembly().GetManifestResourceStream("sweeper.Bitmap1.bmp"));
        Bitmap bombBMP = new Bitmap(System.Reflection.Assembly.GetEntryAssembly().GetManifestResourceStream("sweeper.Bitmap2.bmp"));
        
        string[] readText = File.ReadAllLines(path: Path);

        
        public Form1()
        {
            //intital losses and wins to the file that is in the path
            string OVERALLLOSSESstr = readText[0];
            string OVERALLWINSstr = readText[1];

            OVERALLLoSSES = Int32.Parse(OVERALLLOSSESstr);
            OVERALLWINS = Int32.Parse(OVERALLWINSstr);  

            //file the board with bombs, numbers, and colors
            InitializeComponent();
            Fillboard();
            placeBombs(board, MAXBOMBS);
            placeNumbers(board);
            fillColors(board);



        }

        //fill color method that fills each number based on how many bombs are around the tile.
        public void fillColors(Cell[,] board)
        {
            for (int row = 0; row < board.GetLength(0); row++)
            {
                for(int col = 0; col < board.GetLength(1); col++)
                {
                    switch(board[row, col].Number)
                    {
                        case 0:
                            board[row, col].BackgroundColor = Color.LightGray;
                            board[row, col].text = " ";
                            board[row, col].IsBomb = false;
                            break;

                        case 1:
                            board[row, col].BackgroundColor = Color.LimeGreen;
                            board[row, col].IsBomb = false;
                            break;

                        case 2:
                            board[row, col].BackgroundColor = Color.LightYellow;
                            board[row, col].IsBomb = false;
                            break;

                        case 3:
                            board[row, col].BackgroundColor = Color.Orange;
                            board[row, col].IsBomb = false;
                            break;

                        case 4:
                            board[row, col].BackgroundColor = Color.LightPink;
                            board[row, col].IsBomb = false;
                            break;

                        case 5:
                            board[row, col].BackgroundColor = Color.Cyan;
                            board[row, col].IsBomb = false;
                            break;

                        case 6:
                            board[row, col].BackgroundColor = Color.Navy;
                            board[row, col].IsBomb = false;
                            break;

                        case 7:
                            board[row, col].BackgroundColor = Color.BlueViolet;
                            board[row, col].IsBomb = false;
                            break;

                        case 8:
                            board[row, col].BackgroundColor = Color.Violet;
                            board[row, col].IsBomb = false;
                            break;
                    }

                    if (board[row, col].IsBomb)
                    {
                        board[row, col].BackgroundColor = Color.Red;
                    }
                }
            }
        }

        //fills the board with cells in a 10 x 10 grid
        public void Fillboard()
        {
            for(int row = 0; row < board.GetLength(0); row++)
            {
                for(int col = 0; col < board.GetLength(1); col++)
                {
                    board[row, col] = new Cell();
                    board[row, col].X = row;
                    board[row, col].Y = col;
                    board[row, col].BackgroundColor = Color.White;
                    board[row, col].Location = new Point(row * board[row, col].CellSize.Width, (col * board[row, col].CellSize.Height) + theMenuStrip.Height);
                    board[row, col].CellClick += OnCellClick;
                    this.Controls.Add(board[row, col]);
                    
                    
                    
                }
            }
        }

        //method that checks whether all the bombs have been diffused or not.
        public bool EndGame(Cell[,] board)
        {

            bool resultValue = true;
            for (int row = 0; row < board.GetLength(0); row++)
            {
                for (int col = 0; col < board.GetLength(1); col++)
                {
                    if (board[row, col].IsBomb == true)
                    {
                        resultValue = false;
                        return resultValue;

                        
                    }

                    else
                    {
                        resultValue = true;
                        
                    }
                }
            }

            return resultValue;
        }

        //places the bombs on the board based on how many bombs are in the MAXBombs constant
        public void placeBombs(Cell[,] board, int MaxBombs)
        {
            for(int i =0; i < MAXBOMBS; i ++)
            {
                int randomX = random.Next(9);
                int randomY = random.Next(9);

                if (board[randomX, randomY].BackgroundColor == Color.White)
                {
                    board[randomX, randomY].BackgroundColor = Color.Red;
                    board[randomX, randomY].IsBomb = true;
                    board[randomX, randomY].Number = 9;
                    board[randomX, randomY].Image = bombBMP;
                }
            }
            
        }

        //places the numbers on the board based on how many bombs are around the cell.
        public void placeNumbers(Cell[,] board)
        {
           Color testColor = Color.Red;

            printBoard(board);

            for(int row = 0; row< board.GetLength(0); row++)
            {
                for(int col = 0; col < board.GetLength(1); col++)
                {
                    if(!board[row, col].IsBomb)
                    {
                        int bombs = getBombs(row, col, board);
                        board[row, col].Number = bombs;
                        board[row, col].text = board[row, col].Number.ToString();
                        
                    }
                    
                }
            }
            

        }

        //gets how many bombs are around a given cell.
        public int getBombs(int row, int col, Cell[,] board)
        {
            int bombs = 0;
            Color mineColor = Color.Red;
            bombs += getBombLeft(row, col, board, mineColor);
            bombs += getBombRight(row, col, board, mineColor);
            bombs += GetBombAbove(row, col, board, mineColor);
            bombs += GetBombBelow(row, col, board, mineColor);

            return bombs;
        }

        //click method that holds the game logic and checks whether you win or lose.
        public void OnCellClick(object ?sender, CellClickEventArgs e)
        {
            Color targetColor = board[e.X, e.Y].BackgroundColor;
            Color mineColor = Color.Red;
            bool endgame = EndGame(board);
            if(board[e.X, e.Y].IsBomb)
            {
                string message = "Game Over! You Lose";
                MessageBox.Show(message);
                OVERALLLoSSES++;
                string writeString = OVERALLLoSSES.ToString() + "\n" + OVERALLWINS.ToString();
                File.WriteAllText(Path, writeString);
                Application.Restart();
                this.Close();



            }

            else if (endgame)
            {
                string message = "You Win!";
                MessageBox.Show(message);
                OVERALLWINS++;
                string writeString = OVERALLLoSSES.ToString() + "\n" + OVERALLWINS.ToString();
                File.WriteAllText(Path, writeString);
                Application.Restart();
                this.Close();
                
            }

            if (!endgame)
            {
                CheckRight(e, targetColor);
                CheckLeft(e, targetColor);
                CheckRowAbove(e, targetColor);
                CheckRowBelow(e, targetColor);
            }
            

        }

        //helper method for finding how many bombs are near the tile.
        public int getBombLeft(int row, int col, Cell[,] board, Color mineColor)
        {
            int returnValue = 0;
            if (row >= 0 &&
                col > 0)
            {
                if (board[row, col-1].BackgroundColor == mineColor)
                {
                    returnValue = 1;
                }
            }

            return returnValue;
        }

        //helper method for finding how many bombs are near the tile.
        public int getBombRight(int row, int col, Cell[,] board, Color mineColor)
        {
            int returnValue = 0;
            if (row >= 0 &&
                col < board.GetLength(1) - 1)
            {
                if (board[row, col+1].BackgroundColor == mineColor)
                {
                    returnValue = 1;
                }
            }

            return returnValue;
        }

        //helper method for finding how many bombs are near the tile.
        private int GetBombAbove(int row, int col, Cell[,] board, Color mineColor)
        {
            int returnValue = 0;
            returnValue += getBombLeft( row-1, col, board, mineColor);
            if (row > 0)
            {
                if (board[row-1, col].BackgroundColor == mineColor)
                {
                    returnValue++;
                }
            }
            returnValue += getBombRight(row-1, col, board, mineColor);
            return returnValue;
        }

        //helper method for finding how many bombs are near the tile.
        private int GetBombBelow(int row, int col, Cell[,] board, Color mineColor)
        {
            int returnValue = 0;
            if (row < board.GetLength(0) - 1)
            {
                returnValue += getBombLeft(row+1, col, board, mineColor);
                if (board[row+1, col].BackgroundColor == mineColor)
                {
                    returnValue++;
                }
                returnValue += getBombRight(row+1, col, board, mineColor);
            }

            return returnValue;
        }

        
        /// <summary>
        /// checks the row below as well as the diagonals below the clicked square
        /// </summary>
        /// <param name="e"></param>
        /// <param name="targetColor"></param>
        private void CheckRowBelow(CellClickEventArgs e, Color targetColor)
        {
            //down check
            if (e.Y < board.GetLength(1) - 1)
            {
                CheckLeft(e,targetColor);
                if (board[e.X, e.Y + 1].BackgroundColor == targetColor || board[e.X, e.Y + 1].Number == 1)
                {
                    board[e.X, e.Y + 1].PerformClick();
                }
                CheckRight(e, targetColor);
            }
        }

        /// <summary>
        /// Checks the row above as well as the diagonals above
        /// </summary>
        /// <param name="e"></param>
        /// <param name="targetColor"></param>
        private void CheckRowAbove(CellClickEventArgs e, Color targetColor)
        {
            //up check
            CheckLeft(e, targetColor);
            if (e.Y > 0)
            {
                if (board[e.X, e.Y - 1].BackgroundColor == targetColor || board[e.X, e.Y - 1].Number == 1)
                {
                    board[e.X, e.Y - 1].PerformClick();
                }
            }
            CheckRight(e, targetColor);
        }

        private void CheckLeft(CellClickEventArgs e, Color targetColor)
        {
            //to the left
            if (e.X > 0)
            {
                if (board[e.X - 1, e.Y].BackgroundColor == targetColor)
                {
                    board[e.X - 1, e.Y].PerformClick();
                }
            }
        }

        private void CheckRight(CellClickEventArgs e, Color targetColor)
        {
            //to the right
            if (e.X < board.GetLength(1) - 1)
            {
                if (board[e.X + 1, e.Y].BackgroundColor == targetColor)
                {
                    board[e.X + 1, e.Y].PerformClick();
                }
            }
        }

        //timer ticker that increments every second and places it on the board.
        private void GameTimer_Tick(object sender, EventArgs e)
        {
            elapsedTime++;
            toolStripStatusLabel1.Text = $"Time: {elapsedTime} sec ";
        }

        //exit button the closes the applicaiton.
        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            System.Windows.Forms.Application.ExitThread();
        }

        //restarts the game and also increments the lose counter
        private void restartGameToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OVERALLLoSSES++;
            string writeString = OVERALLLoSSES.ToString() + OVERALLWINS.ToString();
            File.WriteAllText(Path, writeString);
            Application.Restart();
            
            
        }

        //debugging method that helps see where the bombs were
        private void printBoard(Cell[,] board)
        {
            for (int row = 0; row < board.GetLength(0); row++)
            {
                for (int col = 0; col < board.GetLength(1); col++) {
                    string text = board[row, col].BackgroundColor == Color.Red ? "B " : "- ";
                    System.Diagnostics.Debug.Write(text);
                }
                System.Diagnostics.Debug.Write("\n");
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
        //click event for the instruction menu tool button
        private void instructionsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string message = "Controls:\nright click: to place flag and mark bomb\nleft click: reveal tile that you have clicked\n" +
                "Numbers: they mean how many bombs are around the tile including diagonals.\n Once you have marked all the spaces and revealed all the spaces you will win but if you click a bomb you will lose." +
                "\nOnce you have placed all the flags left click on a flag to check if they are in the right spots.";
            MessageBox.Show(message);
        }

        //click event for the about tool button
        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string message = "Made by Landon Bunker from the C# class (3020 001) on 11/5/2022";
            MessageBox.Show(message);
        }

        //click event for the lifetime statistics which will print the total number of wins and losses
        private void lifetimeStatisticsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string message = "Losses : " + OVERALLLoSSES.ToString() + "\nWins : " + OVERALLWINS.ToString();
            MessageBox.Show(message);
        }
    }
}