﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LINQPractice
{
    public class LINQtest
    {
        string[] names = new string[] { "Bobby", "Hank", "Peggy", "Boomhauer", "Bill"};

        List<string> nameList = new List<string> { "Bob", "Jed", "Sherman", "Kylee", "Aaron", "Chris", "Jett", "Jennifer"};

        
        public string[] Sort()
        {
            var sortResult = from result in nameList
                             where result.Length == 4
                             where result[0] == 'J'
                             select result;

            return sortResult.ToArray();
        }

        public void PrintSorted()
        {
            foreach(var name in Sort())
            {
                Console.WriteLine(name);
            }
        }

    }
}
