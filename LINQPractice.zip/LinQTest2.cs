﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace LINQPractice
{
    public class LinQTest2
    {
        Dictionary<string, NameData> names = new Dictionary<string, NameData>();

        #region Reading in Data
        public void ReadYear(int year)
        {
            try
            {
                StreamReader sr = new StreamReader($"names\\names\\yob{year}.txt");
                while (!sr.EndOfStream)
                {
                    string line = sr.ReadLine()!;
                    string[] data = line.Split(',');
                    char gender = data[1][0];
                    int count = int.Parse(data[2]);

                    if (names.ContainsKey(data[0]))
                    {
                        AddToExistingName(year, data, gender, count);
                    }
                    else
                    {
                        AddNewName(year, data, gender, count);
                    }
                    
                }

            }
            catch(Exception e)
            {
                Console.WriteLine(e.Message);
                Console.WriteLine(e.StackTrace);
            }
            
        }

        private void AddToExistingName(int year, string[] data, char gender, int count)
        {
            if (gender == 'M')
            {
                names[data[0]].MaleInstances.Add(year, count);
            }
            else
            {
                names[data[0]].FemaleInstances.Add(year, count);
            }
        }

        private void AddNewName(int year, string[] data, char gender, int count)
        {
            NameData newName = new NameData();

            if (gender == 'M')
            {
                newName.MaleInstances.Add(year, count);
            }
            else
            {
                newName.FemaleInstances.Add(year, count);
            }

            names.Add(data[0], newName);
        }

        public void ReadAllYears()
        {
            for (int year = 1880; year <= 2016; year++)
            {
                Console.WriteLine($"Reading Year: {year}");
                ReadYear(year);
            }    
        }

        #endregion

        public void BoysNamesSueQuery()
        {
            var getSue = from name in names
                         where name.Key.Equals("Sue")
                         select name;
            Console.WriteLine($"There are {getSue.First().Value.TotalMales} boys names Sue");
        }

        public void KidsNamedDaenerys()
        {
            var getDaenerys= from name in names
                         where name.Key.Equals("Daenerys")
                         select name;
            foreach (var id in getDaenerys)
            Console.WriteLine($"There are {getDaenerys.First().Value.TotalMales} boys names Daenerys");
        }

        public void popularityGokuVsVegeta()
        {
            var getGoku = from name in names
                         where name.Key.Equals("Goku")
                         select name;

            var getVegeta = from name in names
                          where name.Key.Equals("Vegeta")
                          select name;

            int gokuNames = getGoku.First().Value.TotalMales;
            int vegetaNames = getVegeta.First().Value.TotalMales;

            if (gokuNames > vegetaNames)
            {
                Console.WriteLine($"Goku is more popular with {getGoku.First().Value.TotalMales} names");
            }
            else
            {
                Console.WriteLine($"Vegeta is more popular with {getVegeta.First().Value.TotalMales} names");
            }
            
        }
    }
}
