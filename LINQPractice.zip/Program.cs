﻿using LINQPractice;
using System.Text.Encodings.Web;

LinQTest2 test = new LinQTest2();

test.ReadAllYears();
test.KidsNamedDaenerys();
test.popularityGokuVsVegeta();
Console.ReadLine();
