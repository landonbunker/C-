﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LINQPractice
{
    public class NameData
    {
        Dictionary<int, int> maleInstances      = new Dictionary<int, int>();
        Dictionary<int, int> femaleInstances    = new Dictionary<int, int>();
        

        public int TotalMales
        {
            get
            {
                int total = 0;
                foreach(var year in MaleInstances.Keys)
                {
                    total += MaleInstances[year];
                }

                return total;
            }
        }

        public int TotalFemales
        {
            get
            {
                int total = 0;
                foreach (var year in FemaleInstances.Keys)
                {
                    total += FemaleInstances[year];
                }

                return total;
            }
        }

        public int TotalNames
        {
            get
            {
                int total = 0;
                foreach (var year in FemaleInstances.Keys)
                {
                    total += FemaleInstances[year];
                }

                foreach (var year in MaleInstances.Keys)
                {
                    total += MaleInstances[year];
                }

                return total;
            }
        }



        public Dictionary<int, int> MaleInstances { get => maleInstances; set => maleInstances = value; }
        public Dictionary<int, int> FemaleInstances { get => femaleInstances; set => femaleInstances = value; }



    }
}
