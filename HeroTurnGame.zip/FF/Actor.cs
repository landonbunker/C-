﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FF
{
    /// <summary>
    /// Classs that creates all the enemies and heroes
    /// </summary>
    public class Actor
    {

        #region fields
        private string name;
        private string type;
        private string spriteName;
        private int hitPoints;
        private int speed;
        private int strength;
        private int intelligence;
        private int physicalDefense;
        private int magicDefense;
        private bool isDefending;

        #endregion

        public event EventHandler<UpdateEventArgs> AttackedEvent;

        #region Constructor
        public Actor(string name, string type, int hitPoints, int speed, int strength, int intelligence, int physicalDefense, int magicDefense, bool isDefending)
        {
            this.name = name;
            this.type = type;
            this.hitPoints = hitPoints;
            this.speed = speed;
            this.strength = strength;
            this.intelligence = intelligence;
            this.physicalDefense = physicalDefense;
            this.magicDefense = magicDefense;
            this.isDefending = isDefending;
        }

        public Actor(string name, string type, string spriteName, int hitPoints, int speed, int strength, int intelligence, int physicalDefense, int magicDefense, bool isDefending)
        {
            this.name = name;
            this.type = type;
            this.hitPoints = hitPoints;
            this.spriteName = spriteName;
            this.speed = speed;
            this.strength = strength;
            this.intelligence = intelligence;
            this.physicalDefense = physicalDefense;
            this.magicDefense = magicDefense;
            this.isDefending = isDefending;
        }

        public Actor()
        {
            name = "";
            type = "";
        }
        #endregion

        #region Properties
        public string Name { get => name; set => name = value; }
        public string Type { get => type; set => type = value; }
        public int HitPoints { get => hitPoints; set => hitPoints = value; }
        public int Speed { get => speed; set => speed = value; }
        public int Strength { get => strength; set => strength = value; }
        public int Intelligence { get => intelligence; set => intelligence = value; }
        public int PhysicalDefense { get => physicalDefense; set => physicalDefense = value; }
        public int MagicDefense { get => magicDefense; set => magicDefense = value; }
        public bool IsDefending { get => isDefending; set => isDefending = value; }
        public string SpriteName { get => spriteName; set => spriteName = value; }

        #endregion

        #region Methods
        public virtual void Attack(Actor target)
        {
            int totalDamage = this.strength - target.physicalDefense;
            if (target.isDefending == true)
            {
                totalDamage = totalDamage / 2;
            }

            if(totalDamage > 0)
            {
                target.hitPoints = target.hitPoints - totalDamage;
            }
            
            if(target.HitPoints < 0)
            {
                target.hitPoints = 0;
            }

            Attacked(target);
        }

        protected virtual void Attacked(Actor target)
        {
            target.AttackedEvent.Invoke(this, new UpdateEventArgs(0, this));
        }
        public void Defend()
        {
            this.isDefending = true;
        }

        public virtual void Special(Actor target, List<Actor> heroList, List<Actor> enemyList)
        {
            
        }

        #endregion
    }


}