﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FF
{
    /// <summary>
    /// event args that passes the actor whos turn is ready
    /// </summary>
    public class TurnReadyEventArgs : EventArgs
    {
        public TurnReadyEventArgs(Actor actor)
        {
            this.actor = actor;
        }
        public Actor actor;
        public string action;
        public int enemyTag;
    }
}
