using System;

namespace FF
{
    /// <summary>
    /// Class that has all the User interface 
    /// </summary>
    public partial class GameScreen : Form
    {
        public event EventHandler<TurnReadyEventArgs> TurnReady;

        private const string Path = "C:\\Users\\lando\\OneDrive\\Desktop\\ff\\LifeTimeStats.txt";
        Image banditImage = Image.FromFile("C:\\Users\\lando\\private\\FF\\bandit.png");
        Image ogreImage = Image.FromFile("C:\\Users\\lando\\private\\FF\\ogre.png");
        Image dragonImage = Image.FromFile("C:\\Users\\lando\\private\\FF\\dragon.png");

        private string queuedAction;
        GameLogic game = new GameLogic();
        
        List<ActorWidget> heroWidgets = new List<ActorWidget>();
        List<ActorWidget> enemyWidgets = new List<ActorWidget>();
        List<ActorWidget> totalWidgets = new List<ActorWidget>();
        List<ActorWidget> removeWidgets = new List<ActorWidget>();

        List<PictureBox> enemiesPbs = new List<PictureBox>();

        int highestNumberofLevels;
        int highScore;
        int currentScore;
        int currentTurn = 0;
        string[] readText = File.ReadAllLines(path: Path);
        
        /// <summary>
        /// Initial start for the game screen which subscribes everything to events and starts the game logic
        /// </summary>
        public GameScreen()
        {
            string highestNumberofLevelsstr = readText[0];
            string highScorestr = readText[1];
            highestNumberofLevels = Int32.Parse(highestNumberofLevelsstr);
            highScore = Int32.Parse(highScorestr);

            InitializeComponent();
            game.Initialize();
            PrepBoard();

            AttackBtn.Click += ActionButtonClick_Handler;
            DefendBtn.Click += ActionButtonClick_Handler;
            SpecialBtn.Click += ActionButtonClick_Handler;
            
            game.TurnReady += Game_TurnReady;
            
  
            game.StartGame();
            PrepEnemies();

            


        }

        /// <summary>
        /// This method controls each turn and updates all the picture boxes dependant on the turn
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void Game_TurnReady(object? sender, TurnReadyEventArgs e)
        {
            Actor temp = e.actor;
            bool endEncounter = false;

            foreach (ActorWidget actorWidget in totalWidgets)
            {
                if (actorWidget.actor.HitPoints == 0)
                {

                    actorWidget.pictureBox.Visible = false;
                    actorWidget.progressBar.Visible = false;
                    actorWidget.label.Visible = false;
                    
                    removeWidgets.Add(actorWidget);
                }

                else if (actorWidget.actor == temp)
                {
                     actorWidget.TurnReady();
                }
            }

            for(int i =0; i < removeWidgets.Count; i++)
            {
                totalWidgets.Remove(removeWidgets[i]);
                if (removeWidgets[i].actor.Type == "Enemy")
                {
                    enemyWidgets.Remove(removeWidgets[i]);
                    currentScore++;
                }

                if (removeWidgets[i].actor.Type == "Hero"){
                    heroWidgets.Remove(removeWidgets[i]); 
                }
                if (0 == enemyWidgets.Count)
                {
                    endEncounter = true;
                    
                    break;
                }

                if(0 == heroWidgets.Count)
                {
                    string message = "you lost\nDefeated " + currentScore + " Enemies\nCleared " + game.EncounterCount + " Encounters";
                    MessageBox.Show(message);
                    this.Close();
                }
            }
        
            if(endEncounter == false)
            {
                if(temp.HitPoints > 0)
                {
                    BattleLog.AppendText(temp.Name + " is taking a turn.\r\n");

                    if (temp.Type == "Enemy")
                    {
                        game.EnemyTurn(temp);
                        BattleLog.AppendText(temp.Name + " is attacking\r\n");
                        ResetBackColor();
                        Thread.Sleep(1500);

                        game.PlayerTurnDone();
                    }
                }
                else
                {
                    game.PlayerTurnDone();
                }
            }

            if (endEncounter)
            {
                ResetBackColor();
                game.GenerateEncounter();
                PrepEnemies();
                game.StartGame();


                BattleLog.AppendText("Encounter : " + game.EncounterCount + "\r\n");
            }
        }

        /// <summary>
        /// Resets the back color of every widget
        /// </summary>
        public void ResetBackColor()
        {
            foreach (var enemy in enemyWidgets)
            {
                enemy.pictureBox.BackColor = Color.Transparent;
            }

            foreach (var hero in heroWidgets)
            {
                hero.pictureBox.BackColor = Color.Transparent;
            }
        }
        
        /// <summary>
        /// preps the board by creating actor widgets of all the heroes
        /// </summary>
        private void PrepBoard()
        {
            enemy1pb.Visible = false;
            enemy2pb.Visible = false;
            enemy3pb.Visible = false;
            progressBarEnemy1.Visible = false;
            progressBarENemy2.Visible = false;
            progressBarEnemy3.Visible = false;
            ActorWidget hero1 = new ActorWidget(game.HeroList[0], progressBarhero1, Hero1);
            
            heroWidgets.Add(hero1);


            ActorWidget hero2 = new ActorWidget(game.HeroList[1], progressBarhero2, Hero2);
          
            heroWidgets.Add(hero2);

            ActorWidget hero3 = new ActorWidget(game.HeroList[2], progressBarhero3, Hero3);
           
            heroWidgets.Add(hero3);

            totalWidgets.Add(hero1);
            totalWidgets.Add(hero2);
            totalWidgets.Add(hero3);
        }

        /// <summary>
        /// Sets the picture box depending on the name of the actor
        /// </summary>
        /// <param name="actor"></param>
        private void setPictureBox(ActorWidget actor)
        {
            if(actor.actor.Name == "Bandit")
            {
                actor.pictureBox.Image = banditImage;
            }

            else if (actor.actor.Name == "Ogre")
            {
                actor.pictureBox.Image = ogreImage;
            }

            else if (actor.actor.Name == "Dragon")
            {
                actor.pictureBox.Image = dragonImage;
            }
        }

        /// <summary>
        /// Creates widgets for all the enemies as well as resets everything after the encounter is over
        /// </summary>
        private void PrepEnemies()
        {
            if (game.EnemyList.Count >= 1)
            {
                ActorWidget enemy1 = new ActorWidget(game.EnemyList[0], progressBarEnemy1, enemy1pb);
                enemy1.pictureBox.Visible = true;
                enemy1.progressBar.Visible = true;
                enemy1.progressBar.Value = 100;
                setPictureBox(enemy1);
                enemyWidgets.Add(enemy1);

                totalWidgets.Add(enemy1);

                if (game.EnemyList.Count >= 2)
                {
                    ActorWidget enemy2 = new ActorWidget(game.EnemyList[1], progressBarENemy2, enemy2pb);
                    enemy2.pictureBox.Visible = true;
                    enemy2.progressBar.Visible = true;
                    enemy2.progressBar.Value = 100;
                    setPictureBox(enemy2);
                    enemyWidgets.Add(enemy2);
                    totalWidgets.Add(enemy2);

                    if (game.EnemyList.Count == 3)
                    {
                        ActorWidget enemy3 = new ActorWidget(game.EnemyList[2], progressBarEnemy3, enemy3pb);
                        enemy3.pictureBox.Visible = true;
                        enemy3.progressBar.Visible = true;
                        setPictureBox(enemy3);
                        enemy3.progressBar.Value = 100;
                        enemyWidgets.Add(enemy3);
                        totalWidgets.Add(enemy3);
                    }
                }
            }
        }

        /// <summary>
        /// Action button handler that determines the action depending on the button that was clicked
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        public void ActionButtonClick_Handler(object sender, EventArgs e)
        {
            string action = ((Button)sender).Tag.ToString();
            queuedAction = action;

            switch (action)
            {

                case "Attack":
                    queuedAction = "Attack";
                    BattleLog.AppendText("\r\nAttack has been chosen, choose a target.\n");
                    AttackGUI();
                    break;

                case "Defend":
                    queuedAction = "Defend";
                    AttackBtn.Enabled = false;
                    DefendBtn.Enabled = false;
                    SpecialBtn.Enabled = false;

                    BattleLog.AppendText("Defend has been chosen\r\n");

                    Thread.Sleep(1500);
                    
                    AttackBtn.Enabled = true;
                    DefendBtn.Enabled = true;
                    SpecialBtn.Enabled = true;
                    game.PlayerTurn(queuedAction,  null);
                    ResetBackColor();
                    game.PlayerTurnDone();
                    break;

                case "Special":
                    AttackBtn.Enabled = false;
                    DefendBtn.Enabled = false;
                    SpecialBtn.Enabled = false;
                    queuedAction = "Special";
                    BattleLog.AppendText("Special has been chosen.\r\n");

                    Thread.Sleep(1500);

                    AttackBtn.Enabled = true;
                    DefendBtn.Enabled = true;
                    SpecialBtn.Enabled = true;
                    game.PlayerTurn(queuedAction, null);
                    
                    ResetBackColor();
                    game.PlayerTurnDone();
                    
                    break;

            }
        }

        /// <summary>
        /// part of the attack gui
        /// </summary>
        public void AttackGUI()
        {
            AttackBtn.Enabled = false;
            DefendBtn.Enabled = false;
            SpecialBtn.Enabled = false;

            foreach (var enemy in enemyWidgets)
            {
                enemy.pictureBox.BackColor = Color.Red;
                enemy.pictureBox.Click += EnemyPBClick_Handler;
            }
        }

        /// <summary>
        /// this is subscribed when people choose attack on all the enemies
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        public void EnemyPBClick_Handler(object sender, EventArgs e)
        {
            Actor target = (Actor)((PictureBox)sender).Tag;
            BattleLog.AppendText("\r\n" + target.Name + " Has been chosen\r\n");

            Thread.Sleep(2000);

            AttackBtn.Enabled = true;
            DefendBtn.Enabled = true;
            SpecialBtn.Enabled = true;

            game.PlayerTurn(queuedAction, target);

            foreach (var enemy in enemyWidgets)
            {
                enemy.pictureBox.Click -= EnemyPBClick_Handler;
            }
            ResetBackColor();
            game.PlayerTurnDone();

            BattleLog.AppendText("\r\n"+ target.Name +" has " + target.HitPoints + " Health\r\n");
        }

        /// <summary>
        /// Updates the stats of high score and highest level if there were new high scores set
        /// </summary>
        public void updateStats()
        {
            if(currentScore > highScore)
            {
                highScore = currentScore;
            }

            if(game.EncounterCount > highestNumberofLevels)
            {
                highestNumberofLevels = game.EncounterCount;
            }
        }

        /// <summary>
        /// Exit button for the menu strip
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            updateStats();
            string writeString = highestNumberofLevels.ToString() + "\n" + highScore.ToString();
            File.WriteAllText(Path, writeString);
            System.Windows.Forms.Application.ExitThread();
        }

        /// <summary>
        /// restart button for the menu strip
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void restartGameToolStripMenuItem_Click(object sender, EventArgs e)
        {
            updateStats();
            string writeString = highestNumberofLevels.ToString() + "\n" + highScore.ToString();
            File.WriteAllText(Path, writeString);
            Application.Restart();
        }

        /// <summary>
        /// High score and lifetime stats button on menu
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void highScoreToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string message = "Highest number of levels beaten: " + highestNumberofLevels.ToString() + "\nHigh Score: " + highScore.ToString();
            MessageBox.Show(message);
        }

        /// <summary>
        /// about tool strip mmenu button
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string message = "Made by Landon Bunker from the C# class (3020 001). Final Project";
            MessageBox.Show(message);
        }

        /// <summary>
        /// describes the special abilities of the characters
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void specialAbilitiesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string message = "Mage : Deals a powerful magic attack to a random enemy that ignores armor but has a chance of missing\n\nFighter : Deals a physical blow to all enemies\n\nCleric : heals all party members a tiny bit of health";
            MessageBox.Show(message);
        }

        /// <summary>
        /// describes the characters stats
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void statsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string message = "Mage : Has high magic damage and protection but has weak physical attributes. Slow Speed" +
                "\n\nFighter : Has high physical damage and protection but weak against magic. High Speed\n\nCleric : Good balance of magic and physical traits. Medium Speed";
            MessageBox.Show(message);
        }
    }
}