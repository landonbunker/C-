﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FF
{
    /// <summary>
    /// Cleric class that overrides specific methods from actor
    /// </summary>
    public class Cleric: Actor
    {
        public Cleric(string name, string type, int hitPoints, int speed, int strength, int intelligence, int physicalDefense, int magicDefense, bool isDefending) :
            base(name, type, hitPoints, speed, strength, intelligence, physicalDefense, magicDefense, isDefending)
        {
        }

        public override void Special(Actor target, List<Actor> heroList, List<Actor> enemyList)
        {
            for (int i = 0; i < heroList.Count; i++)
            {
                
                heroList[i].HitPoints += 15;
                if (heroList[i].HitPoints > 100)
                {
                    heroList[i].HitPoints = 100;
                }

                Attacked(heroList[i]);
            }
        }
        
    }
}