﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FF
{
    /// <summary>
    /// Mage class that overrides specific methods from actor
    /// </summary>
    public class Mage : Actor
    {
        Random random = new Random();

        public Mage(string name, string type, int hitPoints, int speed, int strength, int intelligence, int physicalDefense, int magicDefense, bool isDefending) :
            base(name, type, hitPoints, speed, strength, intelligence, physicalDefense, magicDefense, isDefending)
        {
        }

        public override void Attack(Actor target)
        {
            target.HitPoints = target.HitPoints - this.Intelligence;

            int totalDamage = this.Intelligence - target.PhysicalDefense;
            if (target.IsDefending == true)
            {
                totalDamage = totalDamage / 2;
            }

            if (totalDamage > 0)
            {
                target.HitPoints = target.HitPoints - totalDamage;
            }

            if (target.HitPoints < 0)
            {
                target.HitPoints = 0;
            }

            Attacked(target);
        }
        public override void Special(Actor target, List<Actor> heroList, List<Actor> enemyList)
        {
            target.HitPoints = target.HitPoints - 50;

            if (target.HitPoints < 0)
            {
                target.HitPoints = 0;
            }

            Attacked(target);
        }
    }
}