﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FF
{
    /// <summary>
    /// creates the form and starts the game
    /// </summary>
    public class BunkerFinal
    {
        private GameScreen? screen;

        public void Run()
        {
            ApplicationConfiguration.Initialize();
            screen = new GameScreen();

            Application.Run(new GameScreen());
            
        }
    }
}