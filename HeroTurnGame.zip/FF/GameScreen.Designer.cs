﻿namespace FF
{
    partial class GameScreen
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(GameScreen));
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.progressBarhero3 = new System.Windows.Forms.ProgressBar();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.enemy1pb = new System.Windows.Forms.PictureBox();
            this.GameBackGroundPanel = new System.Windows.Forms.Panel();
            this.Hero3 = new System.Windows.Forms.PictureBox();
            this.Hero2 = new System.Windows.Forms.PictureBox();
            this.Hero1 = new System.Windows.Forms.PictureBox();
            this.enemy3pb = new System.Windows.Forms.PictureBox();
            this.enemy2pb = new System.Windows.Forms.PictureBox();
            this.SpecialBtn = new System.Windows.Forms.Button();
            this.AttackBtn = new System.Windows.Forms.Button();
            this.DefendBtn = new System.Windows.Forms.Button();
            this.progressBarhero2 = new System.Windows.Forms.ProgressBar();
            this.progressBarhero1 = new System.Windows.Forms.ProgressBar();
            this.BattleLog = new System.Windows.Forms.TextBox();
            this.progressBarEnemy1 = new System.Windows.Forms.ProgressBar();
            this.progressBarENemy2 = new System.Windows.Forms.ProgressBar();
            this.progressBarEnemy3 = new System.Windows.Forms.ProgressBar();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.gameToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.highScoreToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.restartGameToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.specialAbilitiesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.statsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            ((System.ComponentModel.ISupportInitialize)(this.enemy1pb)).BeginInit();
            this.GameBackGroundPanel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Hero3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Hero2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Hero1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.enemy3pb)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.enemy2pb)).BeginInit();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(18, 276);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(66, 23);
            this.textBox2.TabIndex = 5;
            this.textBox2.Text = "Fighter HP";
            // 
            // progressBarhero3
            // 
            this.progressBarhero3.Location = new System.Drawing.Point(90, 376);
            this.progressBarhero3.Name = "progressBarhero3";
            this.progressBarhero3.Size = new System.Drawing.Size(108, 31);
            this.progressBarhero3.TabIndex = 7;
            this.progressBarhero3.Value = 100;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(18, 324);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(66, 23);
            this.textBox3.TabIndex = 8;
            this.textBox3.Text = "Mage HP";
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(18, 376);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(66, 23);
            this.textBox4.TabIndex = 9;
            this.textBox4.Text = "Cleric HP";
            // 
            // enemy1pb
            // 
            this.enemy1pb.BackColor = System.Drawing.Color.Transparent;
            this.enemy1pb.Image = ((System.Drawing.Image)(resources.GetObject("enemy1pb.Image")));
            this.enemy1pb.Location = new System.Drawing.Point(663, 3);
            this.enemy1pb.Name = "enemy1pb";
            this.enemy1pb.Size = new System.Drawing.Size(61, 64);
            this.enemy1pb.TabIndex = 3;
            this.enemy1pb.TabStop = false;
            this.enemy1pb.Tag = "1";
            // 
            // GameBackGroundPanel
            // 
            this.GameBackGroundPanel.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.GameBackGroundPanel.Controls.Add(this.Hero3);
            this.GameBackGroundPanel.Controls.Add(this.Hero2);
            this.GameBackGroundPanel.Controls.Add(this.Hero1);
            this.GameBackGroundPanel.Controls.Add(this.enemy3pb);
            this.GameBackGroundPanel.Controls.Add(this.enemy2pb);
            this.GameBackGroundPanel.Controls.Add(this.enemy1pb);
            this.GameBackGroundPanel.Location = new System.Drawing.Point(18, 27);
            this.GameBackGroundPanel.Name = "GameBackGroundPanel";
            this.GameBackGroundPanel.Size = new System.Drawing.Size(770, 234);
            this.GameBackGroundPanel.TabIndex = 4;
            // 
            // Hero3
            // 
            this.Hero3.BackColor = System.Drawing.Color.Transparent;
            this.Hero3.Image = ((System.Drawing.Image)(resources.GetObject("Hero3.Image")));
            this.Hero3.Location = new System.Drawing.Point(51, 152);
            this.Hero3.Name = "Hero3";
            this.Hero3.Size = new System.Drawing.Size(61, 64);
            this.Hero3.TabIndex = 3;
            this.Hero3.TabStop = false;
            this.Hero3.Tag = "3";
            // 
            // Hero2
            // 
            this.Hero2.BackColor = System.Drawing.Color.Transparent;
            this.Hero2.Image = ((System.Drawing.Image)(resources.GetObject("Hero2.Image")));
            this.Hero2.Location = new System.Drawing.Point(119, 75);
            this.Hero2.Name = "Hero2";
            this.Hero2.Size = new System.Drawing.Size(61, 64);
            this.Hero2.TabIndex = 2;
            this.Hero2.TabStop = false;
            this.Hero2.Tag = "2";
            // 
            // Hero1
            // 
            this.Hero1.BackColor = System.Drawing.Color.Transparent;
            this.Hero1.Image = ((System.Drawing.Image)(resources.GetObject("Hero1.Image")));
            this.Hero1.Location = new System.Drawing.Point(51, 3);
            this.Hero1.Name = "Hero1";
            this.Hero1.Size = new System.Drawing.Size(61, 64);
            this.Hero1.TabIndex = 2;
            this.Hero1.TabStop = false;
            this.Hero1.Tag = "1";
            // 
            // enemy3pb
            // 
            this.enemy3pb.BackColor = System.Drawing.Color.Transparent;
            this.enemy3pb.Image = ((System.Drawing.Image)(resources.GetObject("enemy3pb.Image")));
            this.enemy3pb.Location = new System.Drawing.Point(663, 152);
            this.enemy3pb.Name = "enemy3pb";
            this.enemy3pb.Size = new System.Drawing.Size(61, 64);
            this.enemy3pb.TabIndex = 5;
            this.enemy3pb.TabStop = false;
            this.enemy3pb.Tag = "3";
            // 
            // enemy2pb
            // 
            this.enemy2pb.BackColor = System.Drawing.Color.Transparent;
            this.enemy2pb.Image = ((System.Drawing.Image)(resources.GetObject("enemy2pb.Image")));
            this.enemy2pb.Location = new System.Drawing.Point(561, 75);
            this.enemy2pb.Name = "enemy2pb";
            this.enemy2pb.Size = new System.Drawing.Size(61, 64);
            this.enemy2pb.TabIndex = 4;
            this.enemy2pb.TabStop = false;
            this.enemy2pb.Tag = "2";
            // 
            // SpecialBtn
            // 
            this.SpecialBtn.BackColor = System.Drawing.Color.DarkGray;
            this.SpecialBtn.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.SpecialBtn.Location = new System.Drawing.Point(230, 276);
            this.SpecialBtn.Name = "SpecialBtn";
            this.SpecialBtn.Size = new System.Drawing.Size(138, 42);
            this.SpecialBtn.TabIndex = 10;
            this.SpecialBtn.Tag = "Special";
            this.SpecialBtn.Text = "Special";
            this.SpecialBtn.UseVisualStyleBackColor = false;
            // 
            // AttackBtn
            // 
            this.AttackBtn.BackColor = System.Drawing.Color.DarkGray;
            this.AttackBtn.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.AttackBtn.Location = new System.Drawing.Point(230, 324);
            this.AttackBtn.Name = "AttackBtn";
            this.AttackBtn.Size = new System.Drawing.Size(138, 41);
            this.AttackBtn.TabIndex = 11;
            this.AttackBtn.Tag = "Attack";
            this.AttackBtn.Text = "Attack";
            this.AttackBtn.UseVisualStyleBackColor = false;
            // 
            // DefendBtn
            // 
            this.DefendBtn.BackColor = System.Drawing.Color.DarkGray;
            this.DefendBtn.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.DefendBtn.Location = new System.Drawing.Point(230, 371);
            this.DefendBtn.Name = "DefendBtn";
            this.DefendBtn.Size = new System.Drawing.Size(138, 42);
            this.DefendBtn.TabIndex = 13;
            this.DefendBtn.Tag = "Defend";
            this.DefendBtn.Text = "Defend";
            this.DefendBtn.UseVisualStyleBackColor = false;
            // 
            // progressBarhero2
            // 
            this.progressBarhero2.Location = new System.Drawing.Point(90, 324);
            this.progressBarhero2.Name = "progressBarhero2";
            this.progressBarhero2.Size = new System.Drawing.Size(108, 31);
            this.progressBarhero2.TabIndex = 14;
            this.progressBarhero2.Value = 100;
            // 
            // progressBarhero1
            // 
            this.progressBarhero1.Location = new System.Drawing.Point(90, 276);
            this.progressBarhero1.Name = "progressBarhero1";
            this.progressBarhero1.Size = new System.Drawing.Size(108, 31);
            this.progressBarhero1.TabIndex = 15;
            this.progressBarhero1.Value = 100;
            // 
            // BattleLog
            // 
            this.BattleLog.Location = new System.Drawing.Point(564, 276);
            this.BattleLog.Multiline = true;
            this.BattleLog.Name = "BattleLog";
            this.BattleLog.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.BattleLog.Size = new System.Drawing.Size(224, 147);
            this.BattleLog.TabIndex = 16;
            // 
            // progressBarEnemy1
            // 
            this.progressBarEnemy1.Location = new System.Drawing.Point(389, 276);
            this.progressBarEnemy1.Name = "progressBarEnemy1";
            this.progressBarEnemy1.Size = new System.Drawing.Size(108, 31);
            this.progressBarEnemy1.TabIndex = 17;
            this.progressBarEnemy1.Value = 100;
            // 
            // progressBarENemy2
            // 
            this.progressBarENemy2.Location = new System.Drawing.Point(389, 324);
            this.progressBarENemy2.Name = "progressBarENemy2";
            this.progressBarENemy2.Size = new System.Drawing.Size(108, 31);
            this.progressBarENemy2.TabIndex = 18;
            this.progressBarENemy2.Value = 100;
            // 
            // progressBarEnemy3
            // 
            this.progressBarEnemy3.Location = new System.Drawing.Point(389, 376);
            this.progressBarEnemy3.Name = "progressBarEnemy3";
            this.progressBarEnemy3.Size = new System.Drawing.Size(108, 31);
            this.progressBarEnemy3.TabIndex = 19;
            this.progressBarEnemy3.Value = 100;
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.gameToolStripMenuItem,
            this.helpToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(800, 24);
            this.menuStrip1.TabIndex = 20;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // gameToolStripMenuItem
            // 
            this.gameToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.highScoreToolStripMenuItem,
            this.restartGameToolStripMenuItem,
            this.exitToolStripMenuItem});
            this.gameToolStripMenuItem.Name = "gameToolStripMenuItem";
            this.gameToolStripMenuItem.Size = new System.Drawing.Size(50, 20);
            this.gameToolStripMenuItem.Text = "Game";
            // 
            // highScoreToolStripMenuItem
            // 
            this.highScoreToolStripMenuItem.Name = "highScoreToolStripMenuItem";
            this.highScoreToolStripMenuItem.Size = new System.Drawing.Size(166, 22);
            this.highScoreToolStripMenuItem.Text = "Lifetime Statistics";
            this.highScoreToolStripMenuItem.Click += new System.EventHandler(this.highScoreToolStripMenuItem_Click);
            // 
            // restartGameToolStripMenuItem
            // 
            this.restartGameToolStripMenuItem.Name = "restartGameToolStripMenuItem";
            this.restartGameToolStripMenuItem.Size = new System.Drawing.Size(166, 22);
            this.restartGameToolStripMenuItem.Text = "Restart Game";
            this.restartGameToolStripMenuItem.Click += new System.EventHandler(this.restartGameToolStripMenuItem_Click);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(166, 22);
            this.exitToolStripMenuItem.Text = "Exit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // helpToolStripMenuItem
            // 
            this.helpToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aboutToolStripMenuItem,
            this.specialAbilitiesToolStripMenuItem,
            this.statsToolStripMenuItem});
            this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            this.helpToolStripMenuItem.Size = new System.Drawing.Size(44, 20);
            this.helpToolStripMenuItem.Text = "Help";
            // 
            // aboutToolStripMenuItem
            // 
            this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
            this.aboutToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.aboutToolStripMenuItem.Text = "About";
            this.aboutToolStripMenuItem.Click += new System.EventHandler(this.aboutToolStripMenuItem_Click);
            // 
            // specialAbilitiesToolStripMenuItem
            // 
            this.specialAbilitiesToolStripMenuItem.Name = "specialAbilitiesToolStripMenuItem";
            this.specialAbilitiesToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.specialAbilitiesToolStripMenuItem.Text = "Special Abilities";
            this.specialAbilitiesToolStripMenuItem.Click += new System.EventHandler(this.specialAbilitiesToolStripMenuItem_Click);
            // 
            // statsToolStripMenuItem
            // 
            this.statsToolStripMenuItem.Name = "statsToolStripMenuItem";
            this.statsToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.statsToolStripMenuItem.Text = "Stats";
            this.statsToolStripMenuItem.Click += new System.EventHandler(this.statsToolStripMenuItem_Click);
            // 
            // GameScreen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.progressBarEnemy3);
            this.Controls.Add(this.progressBarENemy2);
            this.Controls.Add(this.progressBarEnemy1);
            this.Controls.Add(this.BattleLog);
            this.Controls.Add(this.progressBarhero1);
            this.Controls.Add(this.progressBarhero2);
            this.Controls.Add(this.DefendBtn);
            this.Controls.Add(this.AttackBtn);
            this.Controls.Add(this.SpecialBtn);
            this.Controls.Add(this.GameBackGroundPanel);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.progressBarhero3);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "GameScreen";
            this.Text = "FF remake";
            ((System.ComponentModel.ISupportInitialize)(this.enemy1pb)).EndInit();
            this.GameBackGroundPanel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.Hero3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Hero2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Hero1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.enemy3pb)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.enemy2pb)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private TextBox textBox2;
        private ProgressBar progressBar3;
        private TextBox textBox3;
        private TextBox textBox4;
        private PictureBox enemy1;
        private Panel GameBackGroundPanel;
        private PictureBox enemy3;
        private PictureBox enemy2;
        private Button SpecialBtn;
        private Button AttackBtn;
        private Button DefendBtn;
        private ProgressBar progressBar4;
        private ProgressBar progressBar1;
        private TextBox BattleLog;
        private PictureBox Hero1;
        private PictureBox Hero3;
        private PictureBox Hero2;
        private ProgressBar progressBarEnemy1;
        private ProgressBar progressBarENemy2;
        private ProgressBar progressBarEnemy3;
        private MenuStrip menuStrip1;
        private ToolStripMenuItem gameToolStripMenuItem;
        private ToolStripMenuItem highScoreToolStripMenuItem;
        private ToolStripMenuItem restartGameToolStripMenuItem;
        private ToolStripMenuItem exitToolStripMenuItem;
        private ToolStripMenuItem helpToolStripMenuItem;
        private ToolStripMenuItem aboutToolStripMenuItem;
        private ProgressBar progressBarhero3;
        private ProgressBar progressBarhero2;
        private ProgressBar progressBarhero1;
        private PictureBox enemy1pb;
        private PictureBox enemy3pb;
        private PictureBox enemy2pb;
        private ToolStripMenuItem specialAbilitiesToolStripMenuItem;
        private ToolStripMenuItem statsToolStripMenuItem;
    }
}