﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FF
{
    /// <summary>
    /// Update event args that updates the characters stats
    /// </summary>
    public class UpdateEventArgs : EventArgs
    {
        public Actor Actor;
        public int Index;

        public UpdateEventArgs(int index, Actor actor)
        {
            this.Index = index;
            this.Actor = actor;
        }
    }
}
