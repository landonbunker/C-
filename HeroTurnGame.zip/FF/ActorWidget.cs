﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FF
{
    /// <summary>
    /// class that groups a label, actor, progressbar, and picturebox
    /// </summary>
    internal class ActorWidget
    {
        public ProgressBar progressBar;
        public PictureBox pictureBox;
        public Label label;
        public Actor actor;

        public ActorWidget(Actor actor, ProgressBar progressBar, PictureBox pictureBox)
        {
            this.actor = actor;
            this.actor.AttackedEvent += Actor_Attacked;
            this.progressBar = progressBar;
            this.pictureBox = pictureBox;
            this.pictureBox.Tag = actor;
        }

        private void Actor_Attacked(object? sender, UpdateEventArgs e)
        {
            progressBar.Value = actor.HitPoints;
        }

        
        public void TurnReady()
        {
            pictureBox.BackColor = Color.Yellow;
            pictureBox.Update();
        }
    }
}
