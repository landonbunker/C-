﻿using Accessibility;
using System;
using System.Collections.Generic;
using System.ComponentModel.Design;
using System.Diagnostics.PerformanceData;
using System.Drawing.Imaging;
using System.Linq;
using System.Text;
using System.Xml.Linq;

namespace FF
{
    /// <summary>
    /// Class that holds all the game logic
    /// </summary>
    public class GameLogic
    {
        private List<Actor> turnOrder = new List<Actor>();
        private int encounterCount;
        private List<Actor> heroList = new List<Actor>();
        private List<Actor> enemyList = new List<Actor>();
        private int currentTurnIndex = 0;

        public event EventHandler<TurnReadyEventArgs> TurnReady;
        public event EventHandler<UpdateEventArgs> ActorAttack;
        public event EventHandler<UpdateEventArgs> EnemyAttack;
        Random random = new Random();

        public List<Actor> HeroList { get => heroList; set => heroList = value; }
        public int CurrentTurnIndex { get => currentTurnIndex; set => currentTurnIndex = value; }
        public List<Actor> EnemyList { get => enemyList; set => enemyList = value; }
        public List<Actor> TurnOrder { get => turnOrder; set => turnOrder = value; }
        public int EncounterCount { get => encounterCount; set => encounterCount = value; }

        /// <summary>
        /// creates the heroes and starts the first encounter
        /// </summary>
        public void Initialize()
        {
            Fighter fighter = new Fighter("Fighter", "Hero", 100, 50, 25, 50, 20, 10, false);
            Mage mage = new Mage("Mage", "Hero", 100, 25, 25, 50, 10, 20, false);
            Cleric cleric = new Cleric("Cleric", "Hero", 100, 35, 35, 35, 15, 15, false);

            HeroList.Add(fighter);
            HeroList.Add(mage);
            HeroList.Add(cleric);
            GenerateEncounter();
        }

        /// <summary>
        /// Starts the first turn
        /// </summary>
        public void StartGame()
        {
            TurnReady.Invoke(this, new TurnReadyEventArgs(TurnOrder[CurrentTurnIndex]));

        }

        /// <summary>
        /// returns a turn list based on the speeed of the actors
        /// </summary>
        /// <param name="heroList"></param>
        /// <param name="enemyList"></param>
        /// <returns></returns>
        public List<Actor> GetTurnList(List<Actor> heroList, List<Actor> enemyList)
        {
            for (int i = 0; i < heroList.Count; i++)
            {
                TurnOrder.Add(heroList[i]);
            }

            for (int i = 0; i < enemyList.Count; i++)
            {
                TurnOrder.Add(enemyList[i]);
            }

            for (int i = 0; i < heroList.Count; i++)
            {
                for (int j = 0; j < i; j++)
                {
                    if (TurnOrder[i].Speed > TurnOrder[j].Speed)
                    {
                        Actor actor = TurnOrder[i];
                        TurnOrder[i] = TurnOrder[j];
                        TurnOrder[j] = actor;
                    }
                }
            }

            return TurnOrder;
        }

        /// <summary>
        /// takes an action dependant on the players turn
        /// </summary>
        /// <param name="Action"></param>
        /// <param name="enemy"></param>
        /// <returns></returns>
        public Actor PlayerTurn(string Action, Actor? enemy)
        {
            Actor currentActor = TurnOrder[currentTurnIndex];

            if (turnOrder[currentTurnIndex].HitPoints == 0)
            {

            }
            else
            {

                switch (Action)
                {
                    case ("Attack"):
                        TurnOrder[CurrentTurnIndex].Attack(enemy);
                        break;

                    case ("Defend"):
                        TurnOrder[CurrentTurnIndex].Defend();
                        break;

                    case ("Special"):
                        int randomTarget = random.Next(0, enemyList.Count);
                        TurnOrder[CurrentTurnIndex].Special(enemyList[randomTarget], HeroList, enemyList);
                        break;
                }
            }


            return currentActor;
        }

        /// <summary>
        /// increments the turn counter and if turn counter is at the end then it will reset
        /// </summary>
        public void PlayerTurnDone()
        {
            if (currentTurnIndex == turnOrder.Count - 1)
            {
                currentTurnIndex = 0;
                foreach (Actor actor in TurnOrder)
                {
                    actor.IsDefending = false;
                }
            }
            else
            {
                currentTurnIndex++;
            }

            TurnReady.Invoke(this, new TurnReadyEventArgs(TurnOrder[currentTurnIndex]));
        }

        /// <summary>
        /// enemy turn and attacks random hero
        /// </summary>
        /// <param name="enemy"></param>
        /// <returns></returns>
        public int EnemyTurn(Actor enemy)
        {
            int targetIndex = random.Next(0, 3);
            if (turnOrder[CurrentTurnIndex].HitPoints == 0)
            {

            }
            else
            {
                enemy.Attack(HeroList[targetIndex]);
            }

            return targetIndex;
        }

        /// <summary>
        /// generates the current encounter and all the enemies and will return a bool whether all the heroes are dead
        /// </summary>
        /// <returns></returns>
        public bool GenerateEncounter()
        {
            EnemyList.Clear();
            TurnOrder.Clear();
            encounterCount++;

            createEnemies();

            TurnOrder = GetTurnList(HeroList, EnemyList);
            CurrentTurnIndex = 0;

            return false;
        }

        /// <summary>
        /// Create an enemy based on a index
        /// </summary>
        /// <param name="index"></param>
        /// <returns></returns>
        public Actor CreateEnemy(int index)
        {
            Actor temp = new Actor();
            if (index == 0)
            {
                Actor enemy = new Actor("Bandit", "Enemy", random.Next(25, 50), random.Next(50, 70), 50, random.Next(1, 10), random.Next(1, 10), random.Next(1, 10), false);
                temp = enemy;
            }

            else if (index == 1)
            {
                Actor enemy = new Actor("Ogre", "Enemy", random.Next(50, 75), random.Next(25, 50), random.Next(1, 40), random.Next(1, 10), random.Next(1, 35), random.Next(1, 5), false);
                temp = enemy;
            }

            else if (index == 2)
            {
                Actor enemy = new Actor("Dragon", "Enemy", random.Next(75, 100), random.Next(10, 25), random.Next(35, 75), random.Next(35, 75), random.Next(25, 50), random.Next(25, 50), false);
                temp = enemy;
            }

            return temp;
        }

        /// <summary>
        /// Method that creates enemies and returns a list of them
        /// </summary>
        /// <param name="statCounter"></param>
        /// <returns></returns>
        public void createEnemies()
        {
            List<Actor> enemies = new List<Actor>();
            List<Actor> listEnemies = new List<Actor>();
            int numberOfEnemies = random.Next(1, 4);

            if (encounterCount < 5)
            {
                for (int i = 0; i < numberOfEnemies; ++i)
                {

                    enemies.Add(CreateEnemy(0));
                }
            }
            else if (encounterCount < 10 & encounterCount >= 5)
            {
                int randomMonster1 = random.Next(0, 2);
                int randomMonster2 = random.Next(0, 2);
                int randomMonster3 = random.Next(0, 2);

                enemies.Add(CreateEnemy(randomMonster1));
                enemies.Add(CreateEnemy(randomMonster2));
                enemies.Add(CreateEnemy(randomMonster3));
            }

            else if (encounterCount < 15 & encounterCount >= 10)
            {
                int randomMonster1 = random.Next(0, 3);
                int randomMonster2 = random.Next(0, 3);
                int randomMonster3 = random.Next(0, 3);

                enemies.Add(CreateEnemy(randomMonster1));
                enemies.Add(CreateEnemy(randomMonster2));
                enemies.Add(CreateEnemy(randomMonster3));
            }

            else
            {
                enemies.Add(CreateEnemy(2));
                enemies.Add(CreateEnemy(2));
                enemies.Add(CreateEnemy(2));
            }

            switch (numberOfEnemies)
            {
                case (1):
                    this.EnemyList.Add(enemies[0]);
                    break;

                case (2):
                    this.EnemyList.Add(enemies[0]);
                    this.EnemyList.Add(enemies[1]);
                    break;

                case 3:
                    this.EnemyList.Add(enemies[0]);
                    this.EnemyList.Add(enemies[1]);
                    this.EnemyList.Add(enemies[2]);
                    break;
            }

        }

    }
}