﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using Battleship;
public class BattleShipGame
{   
    //Declaration of variables
    Gameboard userBoard = new Gameboard();
    Gameboard CPUBoard = new Gameboard();
    char defaultChar = '~';
    char missChar = 'X';
    char hitChar = 'O';
    string userInputStart;
    bool endGame = false;
    bool startBool = false;
    bool shotAllShips = false;
    bool validInputStringRow = false;
    bool validInputNumRow = false;
    bool validInputStringCol = false;
    bool validInputNumCol = false;
    int validInputNum = 0;
    Random random = new Random();
    bool CHEATS = false;
    bool shiphit = false;
    bool checkSunk = false;
    int shipsSunk = 0;
    public void startGame()
    {
        //main loop
        while (!endGame)
        {

            //create the boards and ask user if they want to play
            DisplayWelcomeMessage();
            userBoard.Fill(defaultChar);
            CPUBoard.Fill(defaultChar);
            userInputStart = Console.ReadLine();

            userInputStart = userInputStart.ToUpper();

            startBool = CheckUserinputYorN(userInputStart);


            if (userInputStart == "CHEATS")
            {
                CHEATS = true;
            }


            if ((startBool == true && userInputStart == "Y" ) | CHEATS == true)
            {
                //create all the ships and add them to the array
                List<Ship> shipArray = new List<Ship>();
                CreateAddShip(5, "Carrier", random.Next(0, 2), shipArray);
                CreateAddShip(4, "BattleShip", random.Next(0, 2), shipArray);
                CreateAddShip(3, "Submarine", random.Next(0, 2), shipArray);
                CreateAddShip(3, "Submarine", random.Next(0, 2), shipArray);
                CreateAddShip(2, "Destroyer", random.Next(0, 2), shipArray);
                CreateAddShip(2, "Destroyer", random.Next(0, 2), shipArray);


                shotAllShips = false;


                //placing each ship on the board correctly
                foreach (Ship ship in shipArray)
                {
                    bool overlap = true;

                    while (overlap)
                    {
                        CPUBoard.placeShip(ship, random.Next(0, 10), random.Next(0, 10), shipArray);
                        overlap = ship.overlapShip(shipArray);
                    }

                }
                //main game loop 
                while (!shotAllShips)
                {   
                    //display board depending on if cheats are on
                    if (CHEATS)
                    {
                        CPUBoard.Draw();
                    }
                    else
                    {
                        userBoard.Draw();
                    }
                    

                    Console.WriteLine("\nEnter a number (0-9) for the row guess:");


                    validInputStringRow = int.TryParse(Console.ReadLine(), out int rowGuess);
                    validInputNumRow = CheckUserInputNum(rowGuess);

                    //logic for validating and reading the users guess
                    if (validInputStringRow == true & validInputNumRow == true)
                    {
                        while (validInputStringRow == true & validInputNumRow == true)
                        {
                            Console.WriteLine("\nEnter a number (0-9) for the column guess:");

                            validInputStringCol = int.TryParse(Console.ReadLine(), out int colGuess);
                            validInputNumCol = CheckUserInputNum(colGuess);

                            if (validInputStringCol == true & validInputNumCol == true)
                            {
                                Console.WriteLine("Your guess was " + rowGuess + "," + colGuess);

                                //resetting variables so that you can guess again
                                validInputNumCol = false;
                                validInputStringCol = false;
                                validInputNumRow = false;
                                validInputStringRow = false;

                                //check and see if guess is a hit and if it was a previous guess
                                bool checkHit = CPUBoard.CheckHit(rowGuess, colGuess);
                                bool checkPrev = userBoard.CheckPrev(rowGuess, colGuess);

                                if (checkPrev == true)
                                {
                                    Console.WriteLine("\nYou have already guessed that space try again!");
                                }
                                else
                                {
                                    //place hit if the uesr guessed a ship
                                    if (checkHit == true)
                                    {
                                        userBoard.PlaceHit(hitChar, rowGuess, colGuess);
                                        CPUBoard.PlaceHit(hitChar, rowGuess, colGuess);

                                        //check if a ship is sunk or hit
                                        foreach (Ship ship in shipArray)
                                        {
                                            shiphit = ship.checkHit(rowGuess, colGuess);
                                            ship.checkSunk();

                                            if (shiphit && !ship.getSunk())
                                            {
                                                Console.WriteLine("\n You Hit a ship");
                                                break;
                                            }
                                            else if (shiphit && ship.getSunk() && !ship.getDestroyed())
                                            {
                                                Console.WriteLine("You sunk my " + ship.getName());
                                                shipsSunk++;
                                                ship.setDestroyed(true);
                                                break;

                                            }

                                        }

                                        
                                    }
                                    else
                                    {
                                        // if the user missed update both boards
                                        userBoard.PlaceMiss(missChar, rowGuess, colGuess);
                                        CPUBoard.PlaceMiss(missChar, rowGuess, colGuess);

                                        Console.WriteLine("\n You Missed! Try Again!");
                                    }
                                }
                                //check if the game is over
                                shotAllShips = CPUBoard.CheckEnd();
                                if(shotAllShips)
                                {
                                    Console.WriteLine("You Win!");
                                    
                                    //reset the boards
                                    CPUBoard.Fill(defaultChar);
                                    userBoard.Fill(defaultChar);
                                    CHEATS = false;
                                }
                            }
                            else
                            {
                                Console.WriteLine("Entered an incorrect character! Try Again!");
                            }
                        }
                    }

                    else
                    {
                        Console.WriteLine("Entered an incorrect character! Try Again!");
                    }
                }

            }

            //ends the game if the user selected n
            else if (userInputStart == "N")
            {
                endGame = true;
            }

            
        }    
    }

    /// <summary>
    /// Add a ship to the ship array while creating it
    /// </summary>
    /// <param name="length"></param>
    /// <param name="name"></param>
    /// <param name="orientation"></param>
    /// <param name="shipArray"></param>
    /// <returns></returns>
        public List<Ship> CreateAddShip(int length, string name, int orientation, List<Ship> shipArray)
        {
            Ship tempShip = new Ship(length, name, orientation, false, 0);

            shipArray.Add(tempShip);
            return shipArray;

        }


        public void DisplayWelcomeMessage()
        {
            Console.WriteLine("Welcome to BattleShip!");
            Console.WriteLine("Would you like to play? (Y/N) / (CHEATS)");
        }

        /// <summary>
        /// Checks the user input to see if it is the correct range
        /// </summary>
        /// <param name="num"></param>
        /// <returns></returns>
        public bool CheckUserInputNum(int num)
        {
            bool returnValue = true;
            if (num < 0 || num > 9)
            {
                returnValue = false;
            }
            return returnValue;
        }
        /// <summary>
        /// Checking to see if the user input is y or n for the beginning of the program.
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        public bool CheckUserinputYorN(string input)
        {
            bool returnValue = true;
            if (input != "Y" & input != "N")
            {
                returnValue = false;
            }
            return returnValue;
        }
    
}

        
       

