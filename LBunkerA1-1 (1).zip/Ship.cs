﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Battleship
{
    public class Ship
    {
        //private variables
        private int length;
        private string name;
        private int orientation;
        private bool sunk;
        private int hits;
        private int bowx = -1;
        private int bowy = -1;
        private int sternx = -1;
        private int sterny = -1;
        private bool destroyed;

        //constructor
        public Ship(int length, string name, int orientation, bool sunk, int hits)
        {
            this.length = length;
            this.name = name;
            this.orientation = orientation;
            this.sunk = sunk;
            this.hits = hits;
        }
        //check if the ship is sunk and update var 
        public void checkSunk()
        {
            if (hits == length)
            {
                this.sunk = true;
            }
        }

        //check if the ship was hit 
        public bool checkHit(int rowGuess, int colGuess)
        {
            bool returnValue = false;
            if((this.bowx <= rowGuess) && (this.sternx >= rowGuess) && (this.bowy <= colGuess) && (this.sterny >= colGuess))
            {
                returnValue = true;

                if (this.sunk == true)
                {
                    returnValue = false;
                }
                this.hits++;
            }
            
            return returnValue;
        }

        //check if the ship overlaps another ship during placement
        public bool overlapShip(List<Ship> shipArray)
        {
            bool returnValue = false;

            foreach (Ship ship in shipArray)               
            {
                if (this != ship)
                {
                    if (((ship.bowx <= this.bowx) && (ship.sternx >= this.sternx) && (ship.bowy <= this.bowy) && (ship.sterny >= this.sterny)))
                    {
                        returnValue = true;
                    }
                }
            }

            return returnValue;
        }

        //getters and setters for each variable
        public bool getDestroyed()
        {
            return destroyed;
        }

        public void setDestroyed(bool temp)
        {
            destroyed = temp;
        }
        public bool getSunk()
        {
            return sunk;
        }
        public string getName()
        {
            return name;
        }
        public int getOrientation()
        {
            return orientation;
        }

        public int getLength()
        {
            return length;
        }

        public int getSternX()
        {
            return sternx;
        }

        public int getSterny()
        {
            return sternx;
        }

        public int getBowx()
        {
            return bowx;
        }

        public int getBowy()
        {
            return bowy;
        }

        public void setSternX(int num)
        {
            this.sternx = num;
        }

        public void setSternY(int num)
        {
            this.sterny = num;
        }

        public void setBowX(int num)
        {
            this.bowx = num;
        }

        public void setBowY(int num)
        {
            this.bowy = num;
        }
    }
}