﻿using Battleship;

BattleShipGame game = new BattleShipGame();

game.startGame();




