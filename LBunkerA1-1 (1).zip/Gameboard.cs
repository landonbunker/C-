﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Battleship
{
    public class Gameboard
    {
        char[,] board = new char[10, 10];

        /// <summary>
        /// Place a hit marker on the board
        /// </summary>
        /// <param name="hitchar"></param>
        /// <param name="row"></param>
        /// <param name="col"></param>
        public void PlaceHit(char hitchar, int row, int col)
        {
            board[row, col] = hitchar;
        }

        /// <summary>
        /// Place a miss marker when the user misses
        /// </summary>
        /// <param name="misschar"></param>
        /// <param name="row"></param>
        /// <param name="col"></param>
        public void PlaceMiss(char misschar, int row, int col)
        {
            board[row, col] = misschar;
        }

        /// <summary>
        /// place a ship on the board and make sure it is all the way on the board
        /// </summary>
        /// <param name="ship"></param>
        /// <param name="row"></param>
        /// <param name="col"></param>
        /// <param name="shipArray"></param>
        public void placeShip(Ship ship, int row, int col, List<Ship> shipArray)
        {
            
            ship.setBowX(row);
            ship.setBowY(col);
            int tempC = col;
            int tempR = row;


            if (ship.getOrientation() == 0)
            {
                if (col > 5)
                {
                    for (int i = 0; i < ship.getLength(); i++)
                    {
                        board[row, col - i] = 'S';
                        ship.setSternX(row);
                        ship.setSternY(tempC);
                        tempC--;
                    }
                }
                else
                {
                    for (int i = 0; i < ship.getLength(); i++)
                    {
                        board[row, col + i] = 'S';
                        ship.setSternX(row);
                        ship.setSternY(tempC);
                        tempC++;
                    }
                }
            }

            else
            {
                if (row > 5)
                {
                    for (int i = 0; i < ship.getLength(); i++)
                    {
                        board[row-i, col] = 'S';
                        ship.setSternY(col);
                        ship.setSternX(tempR);
                        tempR--;
                    }
                }

                else
                {
                    for (int i = 0; i < ship.getLength(); i++)
                    {
                        board[row+i, col] = 'S';
                        ship.setSternY(col);
                        ship.setSternX(tempR);
                        tempR++;
                    }
                }
            }
            board[row, col] = 'S';
        }
        
        /// <summary>
        /// Check if the game is over
        /// </summary>
        /// <returns></returns>
        public bool CheckEnd()
        {
            bool returnValue = true;
            for (int i = 0; i < 10; i++)
            {
                for (int j = 0; j < 10; j++)
                {
                    if (board[i, j] == 'S')
                    {
                        returnValue = false;
                    }

                }
            }

            return returnValue;
        }
        /// <summary>
        /// Method to check the guess and if it is a ship then return true
        /// </summary>
        /// <param name="row"></param>
        /// <param name="col"></param>
        /// <returns></returns>
        public bool CheckHit(int row, int col)
        {
            bool returnValue = false;
            if (board[row, col] == 'S')
            {
                returnValue = true;
            }
            return returnValue;
        }

        /// <summary>
        /// check if the user has previously picked that location
        /// </summary>
        /// <param name="row"></param>
        /// <param name="col"></param>
        /// <returns></returns>
        public bool CheckPrev(int row, int col)
        {
            bool returnValue = false;
            if (board[row, col] == 'X' | board[row, col] == 'O')
            {
                returnValue = true;
            }

            return returnValue;
        }
        /// <summary>
        /// Draws gameboard to the console
        /// </summary>
        public void Draw()
        {
            for (int row = 0; row < board.GetLength(0); row++)
            {
                Console.Write($"{row} ");
                for (int col = 0; col < board.GetLength(1); col++)
                {
                    Console.Write($"[{board[row, col]}]");
                }
                Console.WriteLine();
            }

            DrawColNum();
        }

        /// <summary>
        /// Draws out a label row for all the columns
        /// </summary>
        private void DrawColNum()
        {
            Console.Write("  ");
            for (int col = 0; col < board.GetLength(1); col++)
            {
                Console.Write($" {col} ");
            }
        }

        /// <summary>
        /// Fill the board with a selected char
        /// </summary>
        /// <param name="achar"></param> The char you are filling the board with 
        public void Fill(char achar)
        {
            for (int row = 0; row < board.GetLength(0); row++)
            {
                for (int col = 0; col < board.GetLength(1); col++)
                {
                    board[row, col] = achar;
                }
            }
        }
    }
}


