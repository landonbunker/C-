﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BattleShipConsole.Models
{
    class Orientation
    {
        public int x { get; set; } = -1;
        public int y { get; set; } = -1;
    }
}